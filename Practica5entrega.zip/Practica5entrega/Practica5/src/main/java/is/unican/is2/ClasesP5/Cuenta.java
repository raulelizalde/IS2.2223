package is.unican.is2.ClasesP5;

public class Cuenta {
	
	private String numCuenta;
	
	public Cuenta(String numCuenta) {
		this.numCuenta = numCuenta;
	}//wmc +1
	
	public String getNumCuenta() {
		return numCuenta;
	}//wmc +1
	
}
